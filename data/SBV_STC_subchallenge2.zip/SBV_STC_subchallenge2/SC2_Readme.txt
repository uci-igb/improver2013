
Sub-challenge 2 Data File Descriptions:

All files are plain text and tab-delimited.

A)  Gene Expression: Experiments were performed in 4 batches with all stimuli done in triplicate.  All expression data was GCRMA normalized within species and chips of low quality excluded, though all stimuli have at least two replicates after quality control (QC).  Probesets were mapped to gene symbols using Affymetrix annotations: HG-U133 Plus 2, na33 and Rodent 230 2.0, na32.  Probesets mapping to multiple genes were excluded.  In cases of multiple probesets mapping to the same gene, the probeset with the highest average expression over all experimental conditions was selected as representative.  Data for participants represents high quality, normalized gene expression data in the gene symbol namespace.  Column names specify stimulus name, replicate number, and batch number.  Row names are genes. Please note that replicate numbers do not necessarily correspond across batches and across data types.

	1) GEX_rat_train.txt - Rodent GEX for training.
	2) GEX_rat_test.txt - Rodent GEX for testing.
	3) GEX_human_train.txt - Human GEX for training.

		
B)  Phosphorylation data: Phosphoprotein phosphorylation response was measured using the Luminex xMap.  Experiments were performed in triplicate across 2 batches at 5 and 25 minutes.  Batch 1 and 2 have 6 and 5 DME controls, respectively.  After QC, all stimuli have at least 2 replicates at each time point.  Data has been normalized using a robust regression and normalized values are provided as the ratio of residuals to the root mean squared error of the fit.  Column names specify stimulus name, replicate number, and batch number.  Row names are phosphoproteins. Please note that replicate numbers do not necessarily correspond across batches and across data types.

	1) Phospho_5_rat_train.txt - Rodent normalized phosphorylation data at 5 minutes for training.
	2) Phospho_25_rat_train.txt - Rodent normalized phosphorylation data at 25 minutes for training.
	3) Phospho_5_human_train.txt - Human normalized phosphorylation data at 5 minutes for training.
	4) Phospho_25_human_train.txt - Human normalized phosphorylation data at 25 minutes for training.
	*5) Phospho_5_rat_test.txt - Rodent normalized phosphorylation data at 5 minutes for testing.
	*6) Phospho_25_rat_test.txt - Rodent normalized phosphorylation data at 25 minutes for testing.

	*Will be provided after the close of sub-challenge 1


C)  Orthologs: Orthologs were identified using the HGNC Comparison of Orthology Predictions (HCOP).  Only gene symbol mappings between human and rodents were used.  Data was downloaded 12/19/2012 and table has been trimmed to only relevant columns - human and rodent gene symbols.  This list of genes have not been filtered for those present on the Affymetrix arrays.  This mapping was used to compare human and rodent gene expression and gene sets. 12458 orthologs are common between human and rodent Affymetrix arrays after mapping of probesets to genes.

	1) orthologs_used.txt - 2 column tab-delimited text file for Rodent to Human orthology.

D)  Template file: This tab-delimited file is to serve as a template for submission of predictions.  Columns indicate stimuli and rows indicate phosphoproteins.  Values should be confidences from 0 to 1 indicating least to most confident of activation.

	1) template_prediction_SC2_phospho_human.txt